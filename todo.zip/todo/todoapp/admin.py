from django.contrib import admin

from .models import student

admin.site.register(student)
