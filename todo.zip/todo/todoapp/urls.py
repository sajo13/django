
from todoapp import views
from django.conf.urls import url

urlpatterns = [
	url(r'^$' ,views.index,name='index'),

	url(r'^(?P<student_id>[0-9]+)/$', views.detail ,name='detail'),
	url(r'^detail1',views.detail1 ,name='detail1')
]
