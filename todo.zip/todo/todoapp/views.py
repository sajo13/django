from django.shortcuts import render
from django.http import  HttpResponse

from django.template import loader
from .models import student

def index(request):

	studentList = student.objects.all()
	template = loader.get_template('index.html')
	context = {'studentList':studentList}
	return HttpResponse(template.render(context,request))



def detail(request,student_id):
 	return HttpResponse('This is student no %s'% student_id)

def detail1(request):
	studentList = student.objects.all()
	out =""
	for q in studentList:
		out =out + "," + q.studentName + "," + q.studentplace
	return HttpResponse(out) 	